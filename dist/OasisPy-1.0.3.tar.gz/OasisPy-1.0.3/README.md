# **OasisPy**-- Difference Imaging Engine for Optical SETI Applications

See documentation [here](https://oasispy.readthedocs.io/en/latest/?).