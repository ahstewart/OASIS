[![Documentation Status](https://readthedocs.org/projects/oasispy/badge/?version=latest)](https://oasispy.readthedocs.io/en/latest/?badge=latest)

# **OasisPy**-- Difference Imaging Engine for Optical SETI Applications

See documentation [here](https://oasispy.readthedocs.io/en/latest/?).